package CLONpack;

public class CLONconnect {

	public static void main(String[] args) {
		BeginSettingFile ui = new BeginSettingFile();
	}
}
